# Vedit Pro
Professional Video Editing Services Website built with Next.js, Tailwind CSS, and Framer Motion.

## Development
1. npm install
2. npm run dev
3. Open http://localhost:3000

## Deployment
- Recommended: [Vercel](https://vercel.com)
- Alternative: Netlify
