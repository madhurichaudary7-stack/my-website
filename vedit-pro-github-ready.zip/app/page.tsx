"use client";
import { motion, useScroll, useTransform } from "framer-motion";
const fadeUp = { hidden: { opacity: 0, y: 40 }, visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } } };
const fadeLeft = { hidden: { opacity: 0, x: -40 }, visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: "easeOut" } } };
const fadeRight = { hidden: { opacity: 0, x: 40 }, visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: "easeOut" } } };
export default function Home() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 300], [0, 50]);
  return (
    <main className="relative min-h-screen bg-white text-gray-900">
      <section className="relative h-screen flex items-center justify-center text-center overflow-hidden">
        <motion.div style={{ y }} className="absolute inset-0 bg-gradient-to-br from-purple-700 to-violet-500" />
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8 }} className="relative z-10 text-white">
          <h1 className="text-5xl font-extrabold">Vedit Pro</h1>
          <p className="mt-4 text-lg">Professional Video Editing Services</p>
          <button className="mt-6 px-6 py-3 bg-white text-purple-700 font-semibold rounded-xl hover-glow-strong ripple">Get a Quote</button>
        </motion.div>
      </section>
      <section className="py-20 px-6 max-w-6xl mx-auto">
        <motion.h2 variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-3xl font-bold text-center mb-12">Our Services</motion.h2>
        <div className="grid md:grid-cols-3 gap-8">
          {["Wedding Edits", "Corporate Videos", "Social Media Reels"].map((service, i) => (
            <motion.div key={i} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} whileHover={{ scale: 1.05, rotateX: 3, rotateY: -3, boxShadow: "0 0 20px rgba(139,92,246,0.5)" }} transition={{ type: "spring", stiffness: 300, damping: 20 }} className="hover-glow-soft ripple p-6 bg-white rounded-2xl shadow">
              <h3 className="font-semibold text-xl">{service}</h3>
              <p className="mt-3 text-gray-600">High-quality {service.toLowerCase()} with professional editing.</p>
            </motion.div>
          ))}
        </div>
      </section>
      <section className="py-20 px-6 bg-gray-50">
        <motion.h2 variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-3xl font-bold text-center mb-12">Portfolio</motion.h2>
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {[1,2,3,4].map((item,i)=>(
            <motion.div key={i} variants={i%2===0?fadeLeft:fadeRight} initial="hidden" whileInView="visible" viewport={{once:true}} whileHover={{scale:1.05, rotateX:3, rotateY:-3, boxShadow:"0 0 20px rgba(139,92,246,0.5)"}} transition={{type:"spring", stiffness:300, damping:20}} className="hover-glow-soft ripple p-6 bg-white rounded-2xl shadow">
              <div className="h-40 bg-gray-300 rounded-xl flex items-center justify-center text-gray-500">Video {item}</div>
            </motion.div>
          ))}
        </div>
      </section>
      <section className="py-20 px-6 max-w-4xl mx-auto text-center">
        <motion.h2 variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-3xl font-bold mb-6">Contact Us</motion.h2>
        <p className="mb-6 text-gray-600">WhatsApp / Call: <strong>9481869429</strong> <br/>Email: <strong>vedit.pro7@gmail.com</strong></p>
        <form className="space-y-4">
          <input type="text" placeholder="Your Name" className="w-full p-3 border rounded-lg"/>
          <input type="email" placeholder="Your Email" className="w-full p-3 border rounded-lg"/>
          <textarea placeholder="Your Project Details" className="w-full p-3 border rounded-lg" rows={4}/>
          <button type="submit" className="px-6 py-3 bg-purple-600 text-white rounded-xl hover-glow-strong ripple">Send Message</button>
        </form>
      </section>
    </main>
  );
}